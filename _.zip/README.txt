Alfresco Book Downloads
=======================

This folder contains the following two sub-folders:

1. chapter_downloads
2. full_downloads_alf14

--------------------
1. chapter_downloads
--------------------

Various sample scripts, images and content files are used in each chapter of the Alfresco Book.  In some of the chapters you will also find information to edit various configuration files.

The "chapter_downloads" folder contains sub-folders for individual chapters containing all the required files. Read the individual README.txt file present in each sub-folder to get more details.

-----------------------
2. full_downloads_alf14
-----------------------

This folder contains all the files required to bring up the complete DEMO site as per the Alfresco Book. Read "README.txt" file in this folder for more details.

The demo files present in this folder are applicable ONLY to Alfresco 1.4 Release.
